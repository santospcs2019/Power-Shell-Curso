﻿Set-Location $env:USERPROFILE

@"
This is just a file
stuff1
stuff2
lastline
"@ > "$env:USERPROFILE\file1.txt"



