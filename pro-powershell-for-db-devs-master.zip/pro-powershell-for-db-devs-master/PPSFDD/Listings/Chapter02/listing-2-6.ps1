﻿# Create a file...
"this is a test file created for demostration purposes" > infilepsbook.txt

$myfile = Get-Content infilepsbook.txt

$myfile 
