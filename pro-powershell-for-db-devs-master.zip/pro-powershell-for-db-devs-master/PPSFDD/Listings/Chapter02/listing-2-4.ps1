﻿$myvar = "Bryan"

$myherestring = @"
" Four score and $ * 

Seven years… ,,, ~` ‘ ago

$myvar

!
"
"@

Write-Host $myherestring 
