﻿# Create an array of integers…
$array = (1,2,3,4,5)
foreach ($item in $array) {write-Host $item} 

# Create an array of strings..
$array = ("Mary","Joe","Tom","Harry","Lisa")
foreach ($item in $array) {write-Host $item}
