﻿workflow simple ([string] $myparm)
{
   "Parameter is $myparm"

   Get-Date

   "Some activity"

   "Third activity"
}

simple "test"
