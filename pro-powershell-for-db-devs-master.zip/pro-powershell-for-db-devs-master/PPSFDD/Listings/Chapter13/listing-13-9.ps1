﻿workflow Invoke-UdwSimpleSequence ([string] $myparm)
{
  sequence
  {
    "First"
    "Second"
    "Third"
  }
}

Invoke-UdwSimpleSequence
