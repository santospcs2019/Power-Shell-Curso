CREATE TABLE [dbo].[StateSalesTaxRate](
	[StateProvinceCD] [varchar](255) NULL,
	[StateProvinceSalesTaxRate] [decimal](5, 2) NULL,
	[CreateDate] [datetime] NULL
) 
