﻿Import-LocalizedData -BindingVariable ds -UICulture es-ES  # Spanish

$ds.Sunday  
$ds.Monday  
$ds.Tuesday 
$ds.Wednesday  
$ds.Thursday 
$ds.Friday  
$ds.Saturday  
