﻿Import-LocalizedData -BindingVariable ds -UICulture de-DE  # German

$ds.Sunday  
$ds.Monday  
$ds.Tuesday 
$ds.Wednesday  
$ds.Thursday 
$ds.Friday  
$ds.Saturday  
