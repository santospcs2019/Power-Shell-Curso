﻿# Folder:  de-DE
ConvertFrom-StringData @"
    Sunday=Sonntag;
    Monday=Montag;
    Tuesday=Deinstag;
    Wednesday=Mittwoch;
    Thursday=Donnerstag;
    Friday=Freitag;
    Saturday=Samstag
"@
