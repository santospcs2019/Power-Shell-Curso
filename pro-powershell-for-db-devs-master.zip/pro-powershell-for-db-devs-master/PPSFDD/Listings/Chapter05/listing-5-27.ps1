﻿# Folder: es-ES
ConvertFrom-StringData @"
    Sunday=domingo
    Monday=lunes
    Tuesday=martes
    Wednesday=miércoles
    Thursday=jueves
    Friday=viernes
    Saturday=sábado
"@
