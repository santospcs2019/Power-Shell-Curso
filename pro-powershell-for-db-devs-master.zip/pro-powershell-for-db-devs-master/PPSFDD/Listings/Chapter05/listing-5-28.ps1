﻿Import-LocalizedData -BindingVariable ds                     # Machine Default - English

$ds.Sunday  
$ds.Monday  
$ds.Tuesday 
$ds.Wednesday  
$ds.Thursday 
$ds.Friday  
$ds.Saturday  
